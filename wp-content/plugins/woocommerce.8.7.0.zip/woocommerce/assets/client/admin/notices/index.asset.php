<?php return array('dependencies' => array('lodash', 'wp-data', 'wp-notices'), 'version' => '46f0614364bec2a020d6');
